package no.hvl.dat110.broker;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import no.hvl.dat110.common.Logger;
import no.hvl.dat110.messages.Message;
import no.hvl.dat110.messages.PublishMsg;
import no.hvl.dat110.messagetransport.Connection;

public class Storage {

	protected ConcurrentHashMap<String, Set<String>> subscriptions;
	protected ConcurrentHashMap<String, ClientSession> clients;
	protected ConcurrentHashMap<String, Queue<Message>> offlineUser;

	public Storage() {
		subscriptions = new ConcurrentHashMap<String, Set<String>>();
		clients = new ConcurrentHashMap<String, ClientSession>();
		offlineUser = new ConcurrentHashMap<String, Queue<Message>>();
	
	} 
	

	public Collection<ClientSession> getSessions() {
		return clients.values();
	}

	public Set<String> getTopics() {

		return subscriptions.keySet();

	}

	public ClientSession getSession(String user) {

		ClientSession session = clients.get(user);

		return session;
	}
	
	

	public Set<String> getSubscribers(String topic) {

		return (subscriptions.get(topic));

	}

	public void addClientSession(String user, Connection connection) {

		// TODO: add corresponding client session to the storage
		
		clients.put(user, new ClientSession(user, connection)); 
		
		//throw new RuntimeException("not yet implemented");
		
	}

	public void removeClientSession(String user) {

		// TODO: remove client session for user from the storage
		clients.remove(user);
          
		// throw new RuntimeException("not yet implemented");
		
	}

	public void createTopic(String topic) {

		// TODO: create topic in the storage
		Set<String> subs = new HashSet<String>();
		subscriptions.put(topic, subs);

	//	throw new RuntimeException("not yet implemented");
	
	}

	public void deleteTopic(String topic) {

		// TODO: delete topic from the storage
		subscriptions.remove(topic);

		throw new RuntimeException("not yet implemented");
		
	}

	public void addSubscriber(String user, String topic) {

		// TODO: add the user as subscriber to the topic
		Set<String> subcriber = subscriptions.get(topic);
		subcriber.add(user);
		subscriptions.put(topic, subcriber);
		
		 //throw new RuntimeException("not yet implemented");
		
	}

	public void removeSubscriber(String user, String topic) {

		// TODO: remove the user as subscriber to the topic
		Set<String> subcriber = subscriptions.get(topic);
		subcriber.remove(user);
		subscriptions.put(topic, subcriber);
		

	//	throw new RuntimeException("not yet implemented");
	}

	public void sendOfflineMessages(ClientSession session, Queue<Message> messages) {
		// TODO Auto-generated method stub
		if (messages.size() == 0) return;
		
		while(!messages.isEmpty()) {
			session.send(messages.poll());
		}
		
	}

	public void addOfflineList(String user) {
		// TODO Auto-generated method stub
		offlineUser.put(user, new LinkedList<>());
		
	}





	public Queue<Message> getOfflineUserMessages(String user) {
		// TODO Auto-generated method stub
		return offlineUser.get(user);
	}
}

