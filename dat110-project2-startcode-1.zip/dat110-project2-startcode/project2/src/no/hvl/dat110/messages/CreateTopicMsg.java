package no.hvl.dat110.messages;

import java.util.HashSet;
import java.util.Set;

public class CreateTopicMsg extends Message {
	
	// TODO: 
	// Implement objectvariables, constructor, get/set-methods, and toString method

		private String topic; // To create topic
		private Set<String> users; // other users
		
		public CreateTopicMsg(String topic, String user) { //constructor
			super(MessageType.CREATETOPIC, user); //Create topic
			users = new HashSet<String>();
			users.add(user);
			this.topic=topic;
			
		}

		public String getTopic() {
			return topic;
		}

		public void setTopic(String topic) {
			this.topic = topic;
		}

		public Set<String> getUsers() {
			return users;
		}

		public void setUsers(Set<String> users) {
			this.users = users;
		}

		@Override
		public String toString() {
			return "CreateTopicMsg [topic=" + topic + ", users=" + users + "]"; //toString method
		}
		
		
		
		
		
		
	
	
	
	
	
	
	
	
}
	
