package no.hvl.dat110.messages;

import java.util.HashSet;
import java.util.Set;

public class PublishMsg extends Message {
	
	// TODO: 
	// Implement objectvariables, constructor, get/set-methods, and toString method
		
		private String topic;
		private Set<String> users;
		private String message; //message
		
		public PublishMsg(String topic, String user, String message) {
			super(MessageType.PUBLISH, user);
			users= new HashSet<String>();
			users.add(user);
			this.topic=topic;
			this.message=message;
		}

		public String getTopic() {
			return topic;
		}

		public void setTopic(String topic) {
			this.topic = topic;
		}

		public Set<String> getUsers() {
			return users;
		}

		public void setUsers(Set<String> users) {
			this.users = users;
		}

		public String getMessage() {
			return message;
		}

		public void setMsg(String message) {
			this.message = message;
		}

		@Override
		public String toString() {
			return "PublishMsg [topic=" + topic + ", users=" + users + ", message=" + message + "]"; //Tostring-method
		}
		
	
	
}

