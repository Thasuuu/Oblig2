package no.hvl.dat110.messagetransport;

public class MessageConfig {

	public static final int SEGMENTSIZE = 128;
	
	public static final int MESSAGINGPORT = 8080;
	public static final String MESSAGINGHOST = "localhost";
}
